<!-- Footer -->
<footer class="main">
	&copy; 2019 
	<a href="http://creativeitem.com"
    	target="_blank">Creativeitem</a>
	| Ekattor, Version 6.1
</footer>
